# ----------------------------------------------------
# Auto-Update Integration: Import updater ops
# ----------------------------------------------------
import os
from os.path import dirname, realpath
import bpy
from bpy.props import StringProperty, BoolProperty, EnumProperty, IntProperty
from bpy_extras.io_utils import ImportHelper, ExportHelper
from .drs_utility import (
    load_drs,
    save_drs,
    load_bmg,
    create_new_bf_scene,
    # DRS_OT_debug_obb_tree,
)
from .ska_utility import export_ska, get_actions
from . import addon_updater_ops
from . import locator_editor
from . import animation_set_editor
from . import material_flow_editor
from . import effect_set_editor
from . import asset_library

bl_info = {
    "name": "SR-ImpEx",
    "author": "Maxxxel",
    "description": "Addon for importing and exporting Battleforge drs/bmg files.",
    "blender": (4, 5, 0),
    "version": (3, 5, 0),
    "location": "File > Import",
    "warning": "",
    "category": "Import-Export",
    "tracker_url": "",
}

is_dev_version = False
resource_dir = dirname(realpath(__file__)) + "/resources"


def update_filename(self, context):
    if self.action and self.action != "None":
        # Ensure we are currently in FILE_BROWSER space
        if context.space_data and context.space_data.type == "FILE_BROWSER":
            params = context.space_data.params
            if params:
                params.filename = bpy.path.ensure_ext(self.action, ".ska")


def available_actions(_self, _context):
    actions = get_actions()  # Your function that returns a list of action names

    # If no actions are available, provide a default fallback
    if not actions:
        return [("None", "No actions available", "")]

    # Otherwise, dynamically construct the EnumProperty items
    return [(act, act, "") for act in actions]


_menus_attached = False


def _attach_menus_idempotent():
    global _menus_attached
    if _menus_attached:
        return
    # Remove old callbacks if they exist (safe if they don't)
    try:
        bpy.types.TOPBAR_MT_file_import.remove(menu_func_import)
    except Exception:  # pylint: disable=broad-exception-caught
        pass
    try:
        bpy.types.TOPBAR_MT_file_export.remove(menu_func_export)
    except Exception:  # pylint: disable=broad-exception-caught
        pass
    # Append once
    bpy.types.TOPBAR_MT_file_import.append(menu_func_import)
    bpy.types.TOPBAR_MT_file_export.append(menu_func_export)
    _menus_attached = True


def _detach_menus_safely():
    global _menus_attached
    try:
        bpy.types.TOPBAR_MT_file_import.remove(menu_func_import)
    except Exception:  # pylint: disable=broad-exception-caught
        pass
    try:
        bpy.types.TOPBAR_MT_file_export.remove(menu_func_export)
    # pylint: disable=broad-exception-caught
    except Exception:
        pass
    _menus_attached = False


# ----------------------------------------------------
# Addon Preferences: A nice menu for update settings
# ----------------------------------------------------
class MyAddonPreferences(bpy.types.AddonPreferences):
    bl_idname = __package__

    auto_check_update: BoolProperty(
        name="Auto-check for Update",
        description="If enabled, auto-check for updates using an interval",
        default=False,
    )  # type: ignore
    updater_interval_months: IntProperty(
        name="Months",
        description="Number of months between checking for updates",
        default=0,
        min=0,
    )  # type: ignore
    updater_interval_days: IntProperty(
        name="Days",
        description="Number of days between checking for updates",
        default=7,
        min=0,
    )  # type: ignore
    updater_interval_hours: IntProperty(
        name="Hours",
        description="Number of hours between checking for updates",
        default=0,
        min=0,
        max=23,
    )  # type: ignore
    updater_interval_minutes: IntProperty(
        name="Minutes",
        description="Number of minutes between checking for updates",
        default=0,
        min=0,
        max=59,
    )  # type: ignore
    skylords_root: StringProperty(
        name="Skylords Reborn Folder",
        description="Path to the game's installation (root folder containing PAKs)",
        subtype="DIR_PATH",
        default="",
    )  # type: ignore

    def draw(self, context):
        layout = self.layout
        addon_updater_ops.check_for_update_background()
        # Add path picker on top
        box = layout.box()
        box.label(text="Asset Library", icon="ASSET_MANAGER")
        box.prop(self, "skylords_root")
        # existing updater UI
        addon_updater_ops.update_settings_ui(self, context)
        addon_updater_ops.update_notice_box_ui(self, context)


class ImportBFModel(bpy.types.Operator, ImportHelper):
    """Import a Battleforge drs/bmg file"""

    bl_idname = "import_scene.drs"
    bl_label = "Import DRS/BMG"
    filename_ext = ".drs;.bmg"
    # this one needs to be named exactly 'filepath' for ExportHelper
    filepath: StringProperty(
        name="File Path",
        description="Filepath used for exporting the SKA",
        maxlen=1024,
        subtype="FILE_PATH",
    )  # type: ignore
    filter_glob: StringProperty(
        default="*.drs;*.bmg", options={"HIDDEN"}, maxlen=255
    )  # type: ignore
    apply_transform: BoolProperty(
        name="Apply Transform",
        description="Workaround for object transformations importing incorrectly",
        default=True,
    )  # type: ignore
    clear_scene: BoolProperty(
        name="Clear Scene", description="Clear the scene before importing", default=True
    )  # type: ignore
    create_size_reference: BoolProperty(
        name="Create Size References",
        description="Creates multiple size references in the scene",
        default=False,
    )  # type: ignore
    import_collision_shape: BoolProperty(
        name="Import Collision Shape",
        description="Import collision shapes",
        default=True,
    )  # type: ignore
    import_animation: BoolProperty(
        name="Import Animation", description="Import animation", default=True
    )  # type: ignore
    smooth_animation: BoolProperty(
        name="Import Animation Smoothing",
        description="Import animation smoothing",
        default=True,
    )  # type: ignore
    import_ik_atlas: BoolProperty(
        name="Import IK Atlas (Experimental)",
        description="Import IK Atlas",
        default=True,
    )  # type: ignore
    import_debris: BoolProperty(
        name="Import Debris", description="Import debris for bmg files", default=True
    )  # type: ignore
    import_modules: BoolProperty(
        name="Import Modules/Locators",
        description="Import modules and locators for drs files",
        default=True,
    )  # type: ignore
    import_construction: BoolProperty(
        name="Import Construction",
        description="Import construction for bmg files",
        default=True,
    )  # type: ignore
    import_geomesh: BoolProperty(
        name="[DEBUG] Import CGeoMesh (DRS only)",
        description="Import additional geometry mesh data.",
        default=False,
    )  # type: ignore
    import_obbtree: BoolProperty(
        name="[DEBUG] Import CGeoOBBTree (DRS only)",
        description="Import additional OBB tree data.",
        default=False,
    )  # type: ignore
    limit_obb_depth: IntProperty(
        name="[DEBUG] Limit OBB Depth",
        description="Limit the depth of the OBB tree.",
        default=5,
        min=1,
        max=1000,
    )  # type: ignore
    import_bb: BoolProperty(
        name="[DEBUG] Import MeshBoundingBox (DRS only)",
        description="Import additional axis-aligned bounding box data.",
        default=False,
    )  # type: ignore

    def draw(self, context):
        # Auto-Update Integration: Addon Updater by using addon_updater_ops.check_for_update_background(context) in the beginning of the function and addon_updater_ops.update_notice_box_ui(self, context) at the end of the function
        addon_updater_ops.check_for_update_background()
        layout = self.layout
        layout.label(text="Import Settings", icon="IMPORT")
        layout.prop(self, "clear_scene")
        layout.prop(self, "apply_transform")
        # Add a separator
        layout.separator()
        # Create an Animation Section
        layout.label(text="Animation Settings", icon="ANIM_DATA")
        layout.prop(self, "import_animation")
        layout.prop(self, "smooth_animation")
        layout.prop(self, "import_ik_atlas")
        # Add a separator
        layout.separator()
        # Create a Modules Section
        layout.label(text="Modules Settings", icon="OBJECT_DATA")
        layout.prop(self, "import_collision_shape")
        layout.prop(self, "import_modules")
        layout.prop(self, "import_construction")
        layout.prop(self, "import_debris")
        # Add a separator
        layout.separator()
        # Debug Section
        layout.label(text="Debug Settings", icon="CONSOLE")
        layout.prop(self, "import_geomesh")
        layout.prop(self, "import_obbtree")
        layout.prop(self, "limit_obb_depth")
        layout.prop(self, "import_bb")
        # layout.prop(self, "create_size_reference")
        if addon_updater_ops.updater.update_ready is True:
            layout.label(
                text="Update available! Please check the preferences.",
                icon="INFO",
            )
        layout.separator()
        addon_updater_ops.update_notice_box_ui(self, context)

    def execute(self, context):
        keywords: list = self.as_keywords(
            ignore=("filter_glob", "clear_scene", "create_size_reference")
        )
        keywords["import_collision_shape"] = self.import_collision_shape
        keywords["import_animation"] = self.import_animation
        keywords["smooth_animation"] = self.smooth_animation
        keywords["import_ik_atlas"] = self.import_ik_atlas
        keywords["import_modules"] = self.import_modules
        keywords["import_construction"] = self.import_construction
        keywords["import_debris"] = self.import_debris

        if self.clear_scene:
            # Delete all collections
            for collection in bpy.data.collections:
                bpy.data.collections.remove(collection)
            # Also clean all actions
            for action in bpy.data.actions:
                bpy.data.actions.remove(action)
            bpy.ops.object.select_all(action="SELECT")
            bpy.ops.object.delete(use_global=False)
            # Purge unused data blocks
            bpy.ops.outliner.orphans_purge(do_recursive=True)

        # Check if the file is a DRS or a BMG file
        if self.filepath.endswith(".drs"):
            keywords.pop("import_debris")
            keywords.pop("import_construction")
            load_drs(context, **keywords)
            return {"FINISHED"}
        elif self.filepath.endswith(".bmg"):
            keywords.pop("import_modules")
            load_bmg(context, **keywords)
            return {"FINISHED"}
        else:
            self.report({"ERROR"}, "Unsupported file type")
            return {"CANCELLED"}


class ExportBFModel(bpy.types.Operator, ExportHelper):
    """Export a Battleforge drs/bmg file"""

    bl_idname: str = "export_scene.drs"
    bl_label: str = "Export DRS"
    filename_ext: str = ".drs"

    # this one needs to be named exactly 'filepath' for ExportHelper
    filepath: StringProperty(
        name="File Path",
        description="Filepath used for exporting the SKA",
        maxlen=1024,
        subtype="FILE_PATH",
    )  # type: ignore
    filter_glob: StringProperty(
        # type: ignore # ignore
        default="*.drs;*.bmg",
        options={"HIDDEN"},
        maxlen=255,
    )
    split_mesh_by_uv_islands: BoolProperty(
        # type: ignore # ignore
        name="Split Mesh by UV Islands",
        description="Split mesh by UV islands",
        default=True,
    )
    flip_normals: BoolProperty(
        # type: ignore # ignore
        name="Flip Normals",
        description="Flip normals if you see them 'blue' in Blender",
        default=False,
    )
    keep_debug_collections: BoolProperty(
        # type: ignore # ignore
        name="Keep Debug Collection",
        description="Keep debug collection in the scene",
        default=False,
    )
    model_type: EnumProperty(
        name="Model Type",
        description="Select the model type",
        items=[
            ("StaticObjectNoCollision", "Static Object (no collision)", ""),
            ("StaticObjectCollision", "Static Object (with collision)", ""),
            ("AnimatedObjectNoCollision", "Animated Object (no collision)", ""),
            ("AnimatedObjectCollision", "Animated Object (with collision)", ""),
            ("AnimatedUnit", "Animated Unit", ""),
        ],
        default="StaticObjectNoCollision",
    )  # type: ignore
    export_all_ska_actions: BoolProperty(
        name="Export All SKA Actions",
        description="Export all SKA actions associated with the model",
        default=True,
    )  # type: ignore
    set_model_name_prefix: EnumProperty(
        name="Model Name Prefix",
        description="Set a prefix for the exported SKA actions",
        items=[
            ("none", "No Prefix", "Export SKA actions without any prefix: idle.ska"),
            ("model_name", "Model Name Prefix", "Prefix SKA actions with the model name: new_model_idle.ska"),
            ("folder_name", "Folder Name Prefix", "Prefix SKA actions with the folder name: new_model_folder_idle.ska"),
            ("keep_existing", "Keep Existing Prefix", "Keep existing prefixes of imported SKA actions: skel_human_2h_idle.ska"),
        ],
        default="none",
    )  # type: ignore
    auto_fix_quad_faces: BoolProperty(
        name="Auto-fix Quad Faces",
        description="Automatically fix quad faces that may cause issues in Battleforge",
        default=True,
    )  # type: ignore

    def draw(self, context):
        layout = self.layout
        layout.label(text="Export Settings", icon="EXPORT")
        layout.prop(self, "model_type")
        layout.separator()
        layout.label(text="Mesh Export Settings", icon="MESH_CUBE")
        layout.prop(self, "split_mesh_by_uv_islands")
        layout.prop(self, "flip_normals")
        layout.prop(self, "auto_fix_quad_faces")
        layout.separator()
        layout.label(text="SKA Export Settings", icon="ANIM_DATA")
        layout.prop(self, "export_all_ska_actions")
        layout.prop(self, "set_model_name_prefix")
        layout.separator()
        layout.label(text="MISC Settings", icon="PREFERENCES")
        layout.prop(self, "keep_debug_collections")
        

    def invoke(self, context, event):
        # Retrieve the active collection from the active layer collection
        active_coll = context.view_layer.active_layer_collection.collection
        coll_name = active_coll.name

        # Strip off the "DRSModel_" prefix if present
        if coll_name.startswith("DRSModel_"):
            model_name = coll_name[9:]
        else:
            model_name = "you havent selected a DRS model collection"

        # Update the file name with the model name
        self.filepath = bpy.path.ensure_ext(model_name, ".drs")
        context.window_manager.fileselect_add(self)
        return {"RUNNING_MODAL"}

    def execute(self, context):
        keywords: list = self.as_keywords(ignore=("filter_glob", "check_existing"))
        keywords["split_mesh_by_uv_islands"] = self.split_mesh_by_uv_islands
        keywords["flip_normals"] = self.flip_normals
        keywords["keep_debug_collections"] = self.keep_debug_collections
        keywords["model_type"] = self.model_type
        keywords["export_all_ska_actions"] = self.export_all_ska_actions
        keywords["set_model_name_prefix"] = self.set_model_name_prefix
        keywords["auto_fix_quad_faces"] = self.auto_fix_quad_faces

        # update model_name by file_path
        model_name = os.path.basename(self.filepath)
        # remove the extension
        model_name = os.path.splitext(model_name)[0]
        keywords["model_name"] = model_name

        self.filepath = bpy.path.ensure_ext(self.filepath, ".drs")

        result = save_drs(context, **keywords)
        if result == {"FINISHED"}:
            self.report({"INFO"}, "Export erfolgreich.")
        else:
            self.report({"ERROR"}, "Export fehlgeschlagen. Details im Popup.")

        # Purge unused data blocks
        bpy.ops.outliner.orphans_purge(do_recursive=True)

        return result


class ExportSKAFile(bpy.types.Operator, ExportHelper):
    """Export a Battleforge ska animation file"""

    bl_idname: str = "export_animation.ska"
    bl_label: str = "Export SKA"
    bl_options = {"REGISTER"}
    filename_ext: str = ".ska"

    filter_glob: StringProperty(
        # type: ignore # ignore
        default="*.ska",
        options={"HIDDEN"},
        maxlen=255,
    )

    # this one needs to be named exactly 'filepath' for ExportHelper
    filepath: StringProperty(
        name="File Path",
        description="Filepath used for exporting the SKA",
        maxlen=1024,
        subtype="FILE_PATH",
    )  # type: ignore

    # Create an enum with all the actions for the selected object
    action: EnumProperty(
        name="Action",
        description="Select the action to export",
        items=available_actions,  # Note: Pass the function, not the call result!
        update=update_filename,
    )  # type: ignore

    def invoke(self, context, event):
        # Retrieve the active collection from the active layer collection
        active_coll = context.view_layer.active_layer_collection.collection
        if not active_coll.name.startswith("DRSModel_"):
            self.report({"ERROR"}, "You haven't selected a DRS model collection")
            return {"CANCELLED"}

        armature = next((o for o in active_coll.objects if o.type == "ARMATURE"), None)
        if armature is None:
            # Check for an Armature_Collection inside the active collection
            armature_coll = active_coll.children.get("Armature_Collection")
            if armature_coll:
                # Be sure not to take the Control_Rig Armature, but the actual Armature*
                armature = next(
                    (o for o in armature_coll.objects if o.type == "ARMATURE" and not o.name.startswith("Control_Rig")), None
                )
                
        if armature is None:
            self.report({"ERROR"}, "No armature found in the selected collection")
            return {"CANCELLED"}

        for obj in context.view_layer.objects:
            obj.select_set(False)
        armature.select_set(True)
        context.view_layer.objects.active = armature

        bpy.ops.object.mode_set(mode="OBJECT")

        actions = get_actions(armature_coll)
        if not actions:
            self.report({"ERROR"}, "No actions found in the selected armature")
            return {"CANCELLED"}
        
        # Get the first valid action
        first_action = next((act for act in actions if act != "None"), None)
        if first_action is None:
            self.report({"ERROR"}, "No valid actions found in the selected armature")
            return {"CANCELLED"}
        self.action = first_action
        self.filepath = bpy.path.ensure_ext(self.action, ".ska")

        context.window_manager.fileselect_add(self)
        return {"RUNNING_MODAL"}

    def draw(self, context):
        layout = self.layout
        layout.label(text="Export Settings", icon="EXPORT")
        layout.prop(self, "action", text="Action")

    def execute(self, context):
        export_ska(context, self.filepath, self.action)
        
        return {"FINISHED"}


class NewBFScene(bpy.types.Operator, ImportHelper):
    """Create a new Battleforge scene with selectable type and collision support"""

    bl_idname = "scene.new_bf_scene"
    bl_label = "New Battleforge Scene"
    bl_options = {"REGISTER", "UNDO"}

    scene_type: EnumProperty(  # type: ignore
        name="Scene Type",
        description="Select the type of scene to create",
        items=[
            ("object", "Static Object", "Create a static object scene"),
            ("object", "Animated Object", "Create an animated object scene"),
        ],
        default="object",
    )

    collision_support: BoolProperty(  # type: ignore
        name="Collision Support",
        description="Include collision shape collections",
        default=False,
    )

    def draw(self, context):
        layout = self.layout
        layout.prop(self, "scene_type")
        layout.prop(self, "collision_support")

    def execute(self, context):
        create_new_bf_scene(self.scene_type, self.collision_support)
        self.report({"INFO"}, "New Battleforge scene created.")
        return {"FINISHED"}


class ShowMessagesOperator(bpy.types.Operator):
    """Display collected messages in a popup dialog."""

    bl_idname = "my_category.show_messages"
    bl_label = "Messages"
    bl_options = {"REGISTER", "INTERNAL"}

    messages: StringProperty()  # type: ignore

    def execute(self, context):
        # Optional actions upon confirmation
        return {"FINISHED"}

    def invoke(self, context, event):
        width = 800
        return context.window_manager.invoke_popup(self, width=width)

    def draw(self, context):
        layout = self.layout
        col = layout.column()
        for message in self.messages.split("\n"):
            col.label(text=message)


def menu_func_import(self, _context):
    self.layout.operator(
        ImportBFModel.bl_idname,
        text="Battleforge (.drs) - "
        + (is_dev_version and "DEV" or "")
        + " v"
        + str(bl_info["version"][0])
        + "."
        + str(bl_info["version"][1])
        + "."
        + str(bl_info["version"][2]),
    )
    self.layout.operator(
        NewBFScene.bl_idname,
        text="New Battleforge Scene - "
        + (is_dev_version and "DEV" or "")
        + " v"
        + str(bl_info["version"][0])
        + "."
        + str(bl_info["version"][1])
        + "."
        + str(bl_info["version"][2]),
    )


def menu_func_export(self, _context):
    self.layout.operator(
        ExportBFModel.bl_idname,
        text="Battleforge (.drs) - "
        + (is_dev_version and "DEV" or "")
        + " v"
        + str(bl_info["version"][0])
        + "."
        + str(bl_info["version"][1])
        + "."
        + str(bl_info["version"][2]),
    )
    self.layout.operator(
        ExportSKAFile.bl_idname,
        text="Battleforge Animation (.ska) - "
        + (is_dev_version and "DEV" or "")
        + " v"
        + str(bl_info["version"][0])
        + "."
        + str(bl_info["version"][1])
        + "."
        + str(bl_info["version"][2]),
    )


def register():
    addon_updater_ops.register(bl_info)
    bpy.utils.register_class(ImportBFModel)
    bpy.utils.register_class(ExportBFModel)
    bpy.utils.register_class(ExportSKAFile)
    bpy.utils.register_class(NewBFScene)
    bpy.utils.register_class(ShowMessagesOperator)
    _attach_menus_idempotent()
    bpy.utils.register_class(MyAddonPreferences)
    # bpy.utils.register_class(DRS_OT_debug_obb_tree)
    locator_editor.register()
    material_flow_editor.register()
    animation_set_editor.register()
    effect_set_editor.register()
    # asset_library.register()


def unregister():
    addon_updater_ops.unregister()
    bpy.utils.unregister_class(ImportBFModel)
    bpy.utils.unregister_class(ExportBFModel)
    bpy.utils.unregister_class(ExportSKAFile)
    bpy.utils.unregister_class(NewBFScene)
    bpy.utils.unregister_class(ShowMessagesOperator)
    _detach_menus_safely()
    bpy.utils.unregister_class(MyAddonPreferences)
    # bpy.utils.unregister_class(DRS_OT_debug_obb_tree)
    locator_editor.unregister()
    material_flow_editor.unregister()
    animation_set_editor.unregister()
    effect_set_editor.unregister()
    # asset_library.unregister()
